# Electron-Minimal-browser

---

wakamiko

デモ用の、アドレスバー・タイトルバーがないブラウザアプリケーション

---

Copyright (c) 2022 YA-androidapp(https://github.com/YA-androidapp) All rights reserved.
